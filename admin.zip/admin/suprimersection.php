

<?php 

include "Model/Modelsuprimersection.php";
include "View/Viewsuprimersection.php";
<?php 

include "Model/Modellistsections.php";
include "View/Viewlistsections.php";
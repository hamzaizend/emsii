<?php 

include "Model/Modelsuprimeradmin.php";
include "View/Viewsuprimeradmin.php";
<?php 

    include "../connexion.inc.php";

    session_start();

    if($_SESSION['role']!='admin' && $_SESSION['role']!='admin_cours' && $_SESSION['role']!='admin_membre' ){

        $_SESSION['flash']['danger']="Vous n'avez pas l'accés a cette page (ADMIN ONLY)";
        header('location: ../index.php');
    
    }

    $req=$bdd->query("SELECT * FROM offre");
    $offres=$req->fetchAll();

    if(isset($_POST['submit'])){
        if(!empty($_POST['search_bar'])){
            $searchbar='%'.$_POST['search_bar'].'%'; 
            $req=$bdd->prepare("SELECT * FROM offre WHERE titre LIKE ? OR image LIKE ? OR contenu LIKE ?");
            $req->execute([$searchbar,$searchbar,$searchbar]);
            $offres=$req->fetchAll();
        }else{
            $req=$bdd->query("SELECT * FROM offre");
            $offres=$req->fetchAll();
        }
    }


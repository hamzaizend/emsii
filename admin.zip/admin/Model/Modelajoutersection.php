<?php 

include "../connexion.inc.php";
session_start();

if($_SESSION['role']!='admin' && $_SESSION['role']!='admin_cours' && $_SESSION['role']!='admin_membre' ){

    $_SESSION['flash']['danger']="Vous n'avez pas l'accés a cette page (ADMIN ONLY)";
    header('location: ../index.php');

}

$errors=array();

if(isset($_POST['add_offre'])){


    if(empty($_POST['titre']) || !preg_match("/^[a-zA-Z]+$/",$_POST['titre'])){
        $errors['titre']="Veuillez saisir un titre valide ou bien remplire ce champ";
    }

    if(empty($_POST['image']) ){
        $errors['image']="Veuillez saisir le lien  image de l'offre";
    }

    if(empty($_POST['contenu'])){
        $errors['contenu']="Veuillez saisir le contenu de l'offre";
    }


    if(empty($errors)){
        $req=$bdd->prepare("INSERT INTO offre(titre,image,contenu) VALUES(?,?,?) ");
        $req->execute([$_POST['titre'],$_POST['image'],$_POST['contenu']]);
        $_SESSION['flash']['success']="La offre a été ajouté avec succées";
        header('location: listesections.php');
        exit();
    }


}

?>
<?php

$bdd=new PDO('mysql:host=localhost;dbname=emsi','root','root');



<?php 

include "Model/Modelajouteradmin.php";
include "View/Viewajouteradmin.php";
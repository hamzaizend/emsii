<?php 

include "Model/Modelajoutersection.php";
include "View/Viewajoutersection.php";
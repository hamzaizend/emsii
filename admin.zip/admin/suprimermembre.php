<?php

include "Model/Modelsuprimermembre.php";
include "View/Viewsuprimermembre.php";

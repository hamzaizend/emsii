<?php 

include "Model/Modelajoutermembre.php";
include "View/Viewajoutermembre.php";